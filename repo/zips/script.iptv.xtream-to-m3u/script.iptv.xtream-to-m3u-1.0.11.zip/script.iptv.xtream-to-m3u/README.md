# Xtream to M3U

This addon converts Xtream categories to and M3U playlist. This is targeted at users of [Kodi](https://kodi.tv/) that utilize the [IPTV Simple Client](https://github.com/kodi-pvr/pvr.iptvsimple) and are having trouble loading large M3U playlists.

## Features

- Integration with the fantastic IPTV Simple Client add-on
- Selection of TV Channel Categories
  - categories will be fetched from provider using xtream API
  - a playlist will be generated whenever selection is made/updated
- Generate M3U playlist and configure it in IPTV Simple Client (incl. EPG link)

## Requirements

- Kodi v.19+
- IPTV Simple Client addon (will be installed & enabled if necessary)
- An Xtream compatible account

## Installation & Configuration

See instructions in [INSTALL.md](docs/INSTALL.md)
