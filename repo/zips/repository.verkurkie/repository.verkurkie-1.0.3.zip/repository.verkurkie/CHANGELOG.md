# v1.0.2
- fix: changelog not being updated in CI

# v1.0.1
- fix: missing version field in pyproject.toml and more

# v1.0.0
- feat: add all repository files, build process and CI workflow

# v0.0.1
- Initial commit
